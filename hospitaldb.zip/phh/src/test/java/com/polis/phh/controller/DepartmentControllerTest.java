package com.polis.phh.controller;

import com.polis.phh.exception.ResourceNotFoundException;
import com.polis.phh.model.Department;
import com.polis.phh.service.DepartmentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
public class DepartmentControllerTest {

    private MockMvc mockMvc;

    @Mock
    private DepartmentService departmentService;

    @InjectMocks
    private DepartmentController departmentController;

    @Test
    public void testGetDepartmentById() throws Exception {
        // Arrange
        mockMvc = MockMvcBuilders.standaloneSetup(departmentController).build();
        Department department = new Department("Cardiology", "Heart-related treatments");
        department.setId(1L);
        when(departmentService.getDepartmentById(1L)).thenReturn(department);

        // Act & Assert
        mockMvc.perform(get("/api/departments/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Cardiology"));
    }

    @Test
    public void testGetDepartmentByIdNotFound() throws Exception {
        // Arrange
        mockMvc = MockMvcBuilders.standaloneSetup(departmentController).build();
        when(departmentService.getDepartmentById(1L))
                .thenThrow(new ResourceNotFoundException("Department not found with id: 1"));

        // Act & Assert
        mockMvc.perform(get("/api/departments/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Department not found with id: 1"));
    }
}
package com.polis.phh.service;

import com.polis.phh.exception.ResourceNotFoundException;
import com.polis.phh.model.Department;
import com.polis.phh.repository.DepartmentRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@Transactional
@Rollback
public class DepartmentServiceTest {

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Test
    public void testGetDepartmentById() {
        // Arrange
        Department department = new Department("Cardiology", "Heart-related treatments");
        department = departmentRepository.save(department);

        // Act
        Department foundDepartment = departmentService.getDepartmentById(department.getId());

        // Assert
        assertThat(foundDepartment).isNotNull();
        assertThat(foundDepartment.getName()).isEqualTo("Cardiology");
    }

    @Test
    public void testGetDepartmentByIdNotFound() {
        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> {
            departmentService.getDepartmentById(999L);
        });
    }
}
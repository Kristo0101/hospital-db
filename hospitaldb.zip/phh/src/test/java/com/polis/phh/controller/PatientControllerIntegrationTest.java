package com.polis.phh.controller;

import com.polis.phh.model.Department;
import com.polis.phh.model.Patient;
import com.polis.phh.repository.DepartmentRepository;
import com.polis.phh.repository.PatientRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class PatientControllerIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Test
    public void testAdmitPatient() {
        // Arrange
        Department department = new Department("Cardiology", "Heart-related treatments");
        department = departmentRepository.save(department);

        Patient patient = new Patient("John Doe", LocalDateTime.now(), "ADMITTED", department);

        // Act
        ResponseEntity<Patient> response = restTemplate.postForEntity(
                "http://localhost:" + port + "/api/patients/admit?departmentId=" + department.getId(),
                patient,
                Patient.class
        );

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getName()).isEqualTo("John Doe");
        assertThat(response.getBody().getStatus()).isEqualTo("ADMITTED");
    }

    @Test
    public void testGetPatientById() {
        // Arrange
        Department department = new Department("Cardiology", "Heart-related treatments");
        department = departmentRepository.save(department);

        Patient patient = new Patient("John Doe", LocalDateTime.now(), "ADMITTED", department);
        patient = patientRepository.save(patient);

        // Act
        ResponseEntity<Patient> response = restTemplate.getForEntity(
                "http://localhost:" + port + "/api/patients/" + patient.getId(),
                Patient.class
        );

        // Assert
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getName()).isEqualTo("John Doe");
    }
}
package com.polis.phh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhhApplicationTests {

    @Test
    void contextLoads() {
    }

}

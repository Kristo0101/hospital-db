package com.polis.phh.repository;

import com.polis.phh.model.Department;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class DepartmentRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Test
    public void testFindById() {
        // Arrange
        Department department = new Department("Cardiology", "Heart-related treatments");
        entityManager.persist(department);
        entityManager.flush();

        // Act
        Department foundDepartment = departmentRepository.findById(department.getId()).orElse(null);

        // Assert
        assertThat(foundDepartment).isNotNull();
        assertThat(foundDepartment.getName()).isEqualTo("Cardiology");
    }

    @Test
    public void testSaveDepartment() {
        // Arrange
        Department department = new Department("Neurology", "Brain-related treatments");

        // Act
        Department savedDepartment = departmentRepository.save(department);

        // Assert
        assertThat(savedDepartment).isNotNull();
        assertThat(savedDepartment.getId()).isNotNull();
        assertThat(savedDepartment.getName()).isEqualTo("Neurology");
    }
}
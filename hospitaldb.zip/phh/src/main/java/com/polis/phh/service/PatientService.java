package com.polis.phh.service;

import com.polis.phh.exception.ResourceNotFoundException;
import com.polis.phh.model.Department;
import com.polis.phh.model.Patient;
import com.polis.phh.model.AdmissionLog;
import com.polis.phh.repository.DepartmentRepository;
import com.polis.phh.repository.PatientRepository;
import com.polis.phh.repository.AdmissionLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private AdmissionLogRepository admissionLogRepository;

    // Admit a patient
    public Patient admitPatient(Patient patient, Long departmentId) {
        Department department = departmentRepository.findById(departmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + departmentId));

        patient.setDepartment(department);
        patient.setStatus("ADMITTED");
        patient.setAdmissionDate(LocalDateTime.now());
        Patient savedPatient = patientRepository.save(patient);

        // Log the admission
        AdmissionLog log = new AdmissionLog();
        log.setPatientId(savedPatient.getId());
        log.setDepartmentId(departmentId);
        log.setAction("ADMITTED");
        log.setTimestamp(LocalDateTime.now());
        admissionLogRepository.save(log);

        return savedPatient;
    }

    // Discharge a patient
    public Patient dischargePatient(Long patientId, String dischargeCause) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + patientId));

        patient.setStatus("DISCHARGED");
        patient.setDischargeCause(dischargeCause);
        patient.setDischargeDate(LocalDateTime.now());
        Patient savedPatient = patientRepository.save(patient);

        // Log the discharge
        AdmissionLog log = new AdmissionLog();
        log.setPatientId(savedPatient.getId());
        log.setDepartmentId(savedPatient.getDepartment().getId());
        log.setAction("DISCHARGED");
        log.setTimestamp(LocalDateTime.now());
        admissionLogRepository.save(log);

        return savedPatient;
    }

    // Get all patients
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    // Get a patient by ID
    public Patient getPatientById(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));
    }

    // Transfer a patient to another department
    public Patient transferPatient(Long patientId, Long newDepartmentId) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + patientId));

        Department newDepartment = departmentRepository.findById(newDepartmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found with id: " + newDepartmentId));

        patient.setDepartment(newDepartment);
        Patient savedPatient = patientRepository.save(patient);

        // Log the department change
        AdmissionLog log = new AdmissionLog();
        log.setPatientId(savedPatient.getId());
        log.setDepartmentId(newDepartmentId);
        log.setAction("TRANSFERRED");
        log.setTimestamp(LocalDateTime.now());
        admissionLogRepository.save(log);

        return savedPatient;
    }
}
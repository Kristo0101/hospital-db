package com.polis.phh.service;

import com.polis.phh.exception.ResourceNotFoundException;
import com.polis.phh.model.AdmissionLog;
import com.polis.phh.repository.AdmissionLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdmissionLogService {

    @Autowired
    private AdmissionLogRepository admissionLogRepository;

    // Get all admission logs
    public List<AdmissionLog> getAllAdmissionLogs() {
        return admissionLogRepository.findAll();
    }

    // Get admission logs by patient ID
    public List<AdmissionLog> getAdmissionLogsByPatientId(Long patientId) {
        List<AdmissionLog> logs = admissionLogRepository.findByPatientId(patientId);
        if (logs.isEmpty()) {
            throw new ResourceNotFoundException("No admission logs found for patient with id: " + patientId);
        }
        return logs;
    }

    // Get admission logs by department ID
    public List<AdmissionLog> getAdmissionLogsByDepartmentId(Long departmentId) {
        List<AdmissionLog> logs = admissionLogRepository.findByDepartmentId(departmentId);
        if (logs.isEmpty()) {
            throw new ResourceNotFoundException("No admission logs found for department with id: " + departmentId);
        }
        return logs;
    }
}
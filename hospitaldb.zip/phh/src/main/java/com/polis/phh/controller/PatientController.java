package com.polis.phh.controller;

import com.polis.phh.model.Patient;
import com.polis.phh.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

    @Autowired
    private PatientService patientService;

    // Admit a patient
    @PostMapping("/admit")
    public ResponseEntity<Patient> admitPatient(@Valid @RequestBody Patient patient, @RequestParam Long departmentId) {
        Patient admittedPatient = patientService.admitPatient(patient, departmentId);
        return new ResponseEntity<>(admittedPatient, HttpStatus.CREATED);
    }

    // Discharge a patient
    @PostMapping("/discharge/{id}")
    public ResponseEntity<Patient> dischargePatient(@PathVariable Long id, @RequestParam String dischargeCause) {
        Patient dischargedPatient = patientService.dischargePatient(id, dischargeCause);
        return new ResponseEntity<>(dischargedPatient, HttpStatus.OK);
    }

    // Get all patients
    @GetMapping
    public ResponseEntity<List<Patient>> getAllPatients() {
        List<Patient> patients = patientService.getAllPatients();
        return new ResponseEntity<>(patients, HttpStatus.OK);
    }

    @GetMapping("/patients")
    public String getAllPatients(Model model) {
        List<Patient> patients = patientService.getAllPatients();
        model.addAttribute("patients", patients);
        return "patients";
    }

    // Get a patient by ID
    @GetMapping("/{id}")
    public ResponseEntity<Patient> getPatientById(@PathVariable Long id) {
        Patient patient = patientService.getPatientById(id);
        return new ResponseEntity<>(patient, HttpStatus.OK);
    }

    // Transfer a patient to another department
    @PostMapping("/transfer/{id}")
    public ResponseEntity<Patient> transferPatient(@PathVariable Long id, @RequestParam Long newDepartmentId) {
        Patient transferredPatient = patientService.transferPatient(id, newDepartmentId);
        return new ResponseEntity<>(transferredPatient, HttpStatus.OK);
    }
}
package com.polis.phh.repository;

import com.polis.phh.model.AdmissionLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AdmissionLogRepository extends JpaRepository<AdmissionLog, Long> {

    // Find all admission logs for a specific patient
    List<AdmissionLog> findByPatientId(Long patientId);

    // Find all admission logs for a specific department
    List<AdmissionLog> findByDepartmentId(Long departmentId);
}
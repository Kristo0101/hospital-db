package com.polis.phh;

import com.polis.phh.model.Department;
import com.polis.phh.model.Patient;
import com.polis.phh.repository.DepartmentRepository;
import com.polis.phh.repository.PatientRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.time.LocalDateTime;

@SpringBootApplication
@EnableJpaRepositories("com.polis.phh.repository")
public class PhhApplication {

    public static void main(String[] args) {
        SpringApplication.run(PhhApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(DepartmentRepository departmentRepository, PatientRepository patientRepository) {
        return args -> {
            // Create and save a department
            Department cardiology = new Department("Cardiology", "Heart-related treatments");
            departmentRepository.save(cardiology);

            // Create and save a patient
            Patient patient = new Patient("John Doe", LocalDateTime.now(), "ADMITTED", cardiology);
            patientRepository.save(patient);

            // Fetch and print departments and patients
            System.out.println("Departments found with findAll():");
            departmentRepository.findAll().forEach(System.out::println);

            System.out.println("Patients found with findAll():");
            patientRepository.findAll().forEach(System.out::println);
        };
    }
}
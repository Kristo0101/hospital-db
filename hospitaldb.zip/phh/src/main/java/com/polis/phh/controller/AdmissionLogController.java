package com.polis.phh.controller;

import com.polis.phh.model.AdmissionLog;
import com.polis.phh.service.AdmissionLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admission-logs")
public class AdmissionLogController {

    @Autowired
    private AdmissionLogService admissionLogService;

    // Get all admission logs
    @GetMapping
    public ResponseEntity<List<AdmissionLog>> getAllAdmissionLogs() {
        List<AdmissionLog> logs = admissionLogService.getAllAdmissionLogs();
        return new ResponseEntity<>(logs, HttpStatus.OK);
    }

    // Get admission logs by patient ID
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<AdmissionLog>> getAdmissionLogsByPatientId(@PathVariable Long patientId) {
        List<AdmissionLog> logs = admissionLogService.getAdmissionLogsByPatientId(patientId);
        return new ResponseEntity<>(logs, HttpStatus.OK);
    }

    // Get admission logs by department ID
    @GetMapping("/department/{departmentId}")
    public ResponseEntity<List<AdmissionLog>> getAdmissionLogsByDepartmentId(@PathVariable Long departmentId) {
        List<AdmissionLog> logs = admissionLogService.getAdmissionLogsByDepartmentId(departmentId);
        return new ResponseEntity<>(logs, HttpStatus.OK);
    }
}